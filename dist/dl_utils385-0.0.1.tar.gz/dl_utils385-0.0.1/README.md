useful code for deep learning projects
